:HL["/_next/static/css/ce45e5801e93ee30.css","style"]
:HL["/_next/static/css/ab997ae57dacdef2.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(frontend)","param":null,"prefetchHints":4208,"slots":{"children":{"name":"locale","param":{"type":"d","key":"ar","siblings":["_not-found","_global-error","admin","api","icon.png","my-route","robots.txt","sitemap.xml"]},"prefetchHints":4144,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4224,"slots":null}}}}}}},"staleTime":300,"buildId":"K9vhtU0YA40N0C8M0xgp0"}
